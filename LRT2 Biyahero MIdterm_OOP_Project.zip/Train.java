/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package j.lrt_midtermproject;

/**
 *
 * @author jacet
 */
import java.time.LocalTime;

public abstract class Train implements CrowdAdvisory {
    private int trainNumber;
    private String direction;
    private Station currentStation;
    
    
    public Train(int trainNumber, String direction, Station currentStation) {
    this.trainNumber = trainNumber;
    this.direction = direction;
    this.currentStation = currentStation;
}

public int getTrainNumber() {
    return trainNumber;
}

public String getDirection() {
    return direction;
}

public Station getCurrentStation() {
    return currentStation;
}
    
    public String  checkCrowdLevel(){
    LocalTime time = LocalTime.now();
    int hour = time.getHour();

        if (hour >= 5 && hour <= 9) {
            return "High";
        }
        else if (hour >= 10 && hour <= 12) {
            return "Mid";
        }
        else if (hour >= 13 && hour <= 15) {
            return "Low";
        }
        else if (hour == 16) {
            return "Mid";
        }
        else if (hour >= 17 && hour <= 19) {
            return "High";
        }
        else if (hour == 20) {
            return "Mid";
        }
       else if (hour == 21) {
           return "Low";
        }
       else {
            return "Closed";
        }
    }
    
    public abstract int getCarCount();

    @Override
    public abstract String getCrowdWarning();
}
    