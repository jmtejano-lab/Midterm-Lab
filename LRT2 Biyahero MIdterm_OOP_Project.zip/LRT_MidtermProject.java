/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package j.lrt_midtermproject;

/**
 *
 * @author jacet
 */
import java.util.Scanner;
import java.time.ZonedDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class LRT_MidtermProject {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Route route = new Route();
        CommuteAssistant assistant = new CommuteAssistant(route);
        DateTimeFormatter format =
        DateTimeFormatter.ofPattern("hh:mm a");

        assistant.generateTrains(10);
        System.out.println("=== LRT-2 COMMUTE ASSISTANT ===");

        boolean running = true;
        while (running) {
            System.out.println("1. Select pickup and destination stations");
            System.out.println("2. View all trains");
            int choice = readNumber(input, "Choose an option: ", 1, 2);
            if (choice == -1) {
                break;
            }

            if (choice == 2) {
                System.out.println("=== ALL 10 TRAINS ===");
                for (Train train : assistant.getTrains()) {
                    System.out.println("Train #" + train.getTrainNumber());
                    System.out.println("Current station: " + train.getCurrentStation().getstationName());
                    System.out.println("Direction: " + train.getDirection());
                    System.out.println("Cars: " + train.getCarCount());
                    System.out.println("Crowd level (time-based estimate): " + train.checkCrowdLevel());
                    System.out.println("Advisory: " + train.getCrowdWarning());
                }
            } else {
                System.out.println("=== STATIONS ===");
                for (int i = 1; i <= 13; i++) {
                    System.out.println(i + ". " + route.getStation(i).getstationName());
                }

                int pickUp = readNumber(input, "Select pickup station: ", 1, 13);
                if (pickUp == -1) {
                    break;
                }

                int destination;
                do {
                    destination = readNumber(input, "Select destination station: ", 1, 13);
                    if (destination == pickUp) {
                        System.out.println("Destination must be different from pickup.");
                    }
                } while (destination == pickUp);
                if (destination == -1) {
                    break;
                }

                Train nextTrain = assistant.getNextTrain(pickUp, destination);
                if (nextTrain == null) {
                    System.out.println("No available train was found.");
                } else {
                    int waitTime = assistant.calculateWaitingTime(pickUp, destination);
                    int travelTime = route.calculateTime(pickUp, destination);
                    int boardingTime;
                    if (pickUp == 1 || pickUp == 13) {
                        boardingTime = route.getDepotTime();
                    } else {
                        boardingTime = route.getStopTime();
                    }
                    int totalTime = waitTime + boardingTime + travelTime;

                    ZonedDateTime now = ZonedDateTime.now(ZoneId.of("Asia/Manila"));
                    ZonedDateTime pickupArrival = now.plusMinutes(waitTime);
                    ZonedDateTime departure = pickupArrival.plusMinutes(boardingTime);
                    ZonedDateTime destinationArrival = departure.plusMinutes(travelTime);

                    System.out.println("=== YOUR TRIP ===");
                    System.out.println("Current time: " + now.format(format) + " PHT");
                    System.out.println("Pickup: " + route.getStation(pickUp).getstationName());
                    System.out.println("Destination: " + route.getStation(destination).getstationName());
                    System.out.println("Travel direction: " + (pickUp < destination ? "Antipolo" : "Recto"));
                    System.out.println("Nearest available train: #" + nextTrain.getTrainNumber());
                    System.out.println("Train is currently at: " + nextTrain.getCurrentStation().getstationName());
                    System.out.println("Current train direction: " + nextTrain.getDirection());
                    System.out.println("Cars: " + nextTrain.getCarCount());
                    System.out.println("Crowd level (time-based estimate): " + nextTrain.checkCrowdLevel());
                    System.out.println("Advisory: " + nextTrain.getCrowdWarning());

                    if (assistant.calculateTrainWait(nextTrain, pickUp, destination) < 0) {
                        System.out.println("This train must turn around at a depot before pickup.");
                    }
                    if (waitTime == 0) {
                        System.out.println("The train is already at your pickup station.");
                    }
                    System.out.println("Waiting time: " + waitTime + " minutes");
                    System.out.println("Train arrives at pickup: " + pickupArrival.format(format) + " PHT");
                    System.out.println("Boarding / station stop: " + boardingTime + " minutes");
                    System.out.println("Train departs pickup: " + departure.format(format) + " PHT");
                    System.out.println("Travel time after departure (including intermediate stops): " + travelTime + " minutes");
                    System.out.println("Pickup arrival to destination: " + (boardingTime + travelTime) + " minutes");
                    System.out.println("Arrival at destination: " + destinationArrival.format(format) + " PHT");
                    System.out.println("Total time from now: " + totalTime + " minutes");
                }
            }

            int again = readNumber(input, "Return to menu? (1 = Yes, 2 = Exit): ", 1, 2);
            running = again == 1;
        }
        System.out.println("Thank you for using LRT-2 Biya-HERO!");
        input.close();
    }

    private static int readNumber(Scanner input, String prompt, int minimum, int maximum) {
        while (true) {
            System.out.print(prompt);
            if (!input.hasNextLine()) {
                return -1;
            }
            try {
                int number = Integer.parseInt(input.nextLine().trim());
                if (number >= minimum && number <= maximum) {
                    return number;
                }
            } catch (NumberFormatException e) {
            }
            System.out.println("Please enter a number from " + minimum + " to " + maximum + ".");
        }
    }
}


