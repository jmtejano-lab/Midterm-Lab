/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package j.lrt_midtermproject;

/**
 *
 * @author jacet
 */

public class ThreeCarTrain extends Train {

    public ThreeCarTrain(int trainNumber, String direction, Station currentStation) {
        super(trainNumber, direction, currentStation);
    }

    @Override
    public int getCarCount() {
        return 3;
    }

    @Override
    public String getCrowdWarning() {
        if (checkCrowdLevel().equals("High")) {
            return "Warning: This train has only 3 cars. Expect a bigger crowdi.";
        } else if (checkCrowdLevel().equals("Mid")) {
            return "This train has 3 cars. Passenger space may be limited.";
        } else {
            return "This train has 3 cars.";
        }
    }
}
