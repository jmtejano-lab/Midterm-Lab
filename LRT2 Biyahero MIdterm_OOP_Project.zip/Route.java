package j.lrt_midtermproject;

import java.util.ArrayList;
import java.util.List;

public class Route {

    private List<Station> stations = new ArrayList<>();
    private List<Integer> travelTime = new ArrayList<>();
    private int stopTime = 3;
    private int depotTime = 5;

    public Route() {

        stations.add(new Station(1, "Recto"));
        stations.add(new Station(2, "Legarda"));
        stations.add(new Station(3, "Pureza"));
        stations.add(new Station(4, "V. Mapa"));
        stations.add(new Station(5, "J. Ruiz"));
        stations.add(new Station(6, "Gilmore"));
        stations.add(new Station(7, "Betty Go Belmonte"));
        stations.add(new Station(8, "Araneta Cubao"));
        stations.add(new Station(9, "Anonas"));
        stations.add(new Station(10, "Katipunan"));
        stations.add(new Station(11, "Santolan"));
        stations.add(new Station(12, "Marikina-Pasig"));
        stations.add(new Station(13, "Antipolo"));

        travelTime.add(2);
        travelTime.add(3);
        travelTime.add(2);
        travelTime.add(2);
        travelTime.add(3);
        travelTime.add(2);
        travelTime.add(2);
        travelTime.add(3);
        travelTime.add(3);
        travelTime.add(3);
        travelTime.add(4);
        travelTime.add(4);
    }

    public Station getStation(int stationNumber) {
        return stations.get(stationNumber - 1);
    }

    public int getStopTime() {
        return stopTime;
    }

    public int getDepotTime() {
        return depotTime;
    }

    public int calculateTime(int pickUp, int destination) {

        int totalTime = 0;

        if (pickUp == destination) {
            return 0;
        }

        else if (pickUp < destination) {

            for (int i = pickUp - 1; i < destination - 1; i++) {

                totalTime += travelTime.get(i);

                if (i < destination - 2) {
                    totalTime += stopTime;
                }
            }
        }

        else {

            for (int i = pickUp - 2; i >= destination - 1; i--) {

                totalTime += travelTime.get(i);

                if (i > destination - 1) {
                    totalTime += stopTime;
                }
            }
        }
        return totalTime;
    }
}