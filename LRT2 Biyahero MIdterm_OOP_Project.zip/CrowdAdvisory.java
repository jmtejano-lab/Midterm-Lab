/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package j.lrt_midtermproject;

/**
 *
 * @author jacet
 */
public interface CrowdAdvisory {

    String getCrowdWarning();

}


