/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package j.lrt_midtermproject;

/**
 *
 * @author jacet
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.time.LocalTime;

public class CommuteAssistant {

    private Route route;
    private List<Train> trains = new ArrayList<>();
    private List<Integer> occupiedStations = new ArrayList<>();
    private Random random = new Random();

    public CommuteAssistant(Route route) {
        this.route = route;
    }

    public void generateTrains(int count) {

        if (count < 1 || count > 13) {
            System.out.println("Train count must be between 1 and 13.");
            return;
        }

        trains.clear();
        occupiedStations.clear();

        for (int i = 1; i <= count; i++) {

            int randDir = random.nextInt(2) + 1;
            String direction;

            if (randDir == 1) {
                direction = "Recto";
            } else {
                direction = "Antipolo";
            }

            int randStation;

            do {
                randStation = random.nextInt(13) + 1;
            } while (occupiedStations.contains(randStation));

            occupiedStations.add(randStation);

            if (randStation == 1) {
                direction = "Antipolo";
            } else if (randStation == 13) {
                direction = "Recto";
            }

            int randType = random.nextInt(2) + 1;
            Train train;

            if (randType == 1) {
                train = new ThreeCarTrain(
                        i, direction, route.getStation(randStation));
            } else {
                train = new FourCarTrain(
                        i, direction, route.getStation(randStation));
            }

            trains.add(train);
        }
    }

    public List<Train> getTrains() {
        return new ArrayList<>(trains);
    }

    public int calculateTrainWait(Train train, int pickUp, int destination) {

        int trainStation = train.getCurrentStation().getstationNumber();
        String direction = train.getDirection();

        if (pickUp == destination) {
            return -1;
        }

        if (pickUp < destination) {

            if (direction.equals("Antipolo") && trainStation <= pickUp) {

                if (trainStation == pickUp) {
                    return 0;
                }

                int waitTime = route.calculateTime(trainStation, pickUp);

                if (trainStation != 1 && trainStation != 13) {
                    waitTime += route.getStopTime();
                } else {
                    waitTime += route.getDepotTime();
                }

                return waitTime;
            }

        } else {

            if (direction.equals("Recto") && trainStation >= pickUp) {

                if (trainStation == pickUp) {
                    return 0;
                }

                int waitTime = route.calculateTime(trainStation, pickUp);

                if (trainStation != 1 && trainStation != 13) {
                    waitTime += route.getStopTime();
                } else {
                    waitTime += route.getDepotTime();
                }

                return waitTime;
            }
        }

        return -1;
    }

    public int calculateDepotWait(Train train, int pickUp, int destination) {

        int trainStation = train.getCurrentStation().getstationNumber();
        String direction = train.getDirection();

        if (pickUp == destination) {
            return -1;
        }

        int waitTime = 0;

        if (trainStation != 1 && trainStation != 13) {
            waitTime += route.getStopTime();
        }

        if (pickUp < destination) {

            if (direction.equals("Recto")) {

                waitTime += route.calculateTime(trainStation, 1);
                waitTime += route.getDepotTime();
                waitTime += route.calculateTime(1, pickUp);

            } else {

                waitTime += route.calculateTime(trainStation, 13);
                waitTime += route.getDepotTime();

                waitTime += route.calculateTime(13, 1);
                waitTime += route.getDepotTime();

                waitTime += route.calculateTime(1, pickUp);
            }

        } else {

            if (direction.equals("Antipolo")) {

                waitTime += route.calculateTime(trainStation, 13);
                waitTime += route.getDepotTime();
                waitTime += route.calculateTime(13, pickUp);

            } else {

                waitTime += route.calculateTime(trainStation, 1);
                waitTime += route.getDepotTime();

                waitTime += route.calculateTime(1, 13);
                waitTime += route.getDepotTime();

                waitTime += route.calculateTime(13, pickUp);
            }
        }

        return waitTime;
    }

    public Train getNextTrain(int pickUp, int destination) {

        if (pickUp < 1 || pickUp > 13 ||
            destination < 1 || destination > 13 ||
            pickUp == destination) {
            return null;
        }

        Train closestTrain = null;
        int shortestWait = Integer.MAX_VALUE;

        for (Train train : trains) {

            int waitTime = calculateTrainWait(train, pickUp, destination);

            if (waitTime >= 0 && waitTime < shortestWait) {
                shortestWait = waitTime;
                closestTrain = train;
            }
        }

        if (closestTrain != null) {
            return closestTrain;
        }

        for (Train train : trains) {

            int waitTime = calculateDepotWait(train, pickUp, destination);

            if (waitTime >= 0 && waitTime < shortestWait) {
                shortestWait = waitTime;
                closestTrain = train;
            }
        }

        return closestTrain;
    }

    public int calculateWaitingTime(int pickUp, int destination) {

        Train nextTrain = getNextTrain(pickUp, destination);

        if (nextTrain == null) {
            return -1;
        }

        int waitTime = calculateTrainWait(nextTrain, pickUp, destination);

        if (waitTime >= 0) {
            return waitTime;
        }

        return calculateDepotWait(nextTrain, pickUp, destination);
    }

    public LocalTime calculatePickupArrival(int pickUp, int destination) {

        int waitTime = calculateWaitingTime(pickUp, destination);

        if (waitTime < 0) {
            return null;
        }

        return LocalTime.now().plusMinutes(waitTime);
    }

    public LocalTime calculateArrivalTime(int pickUp, int destination) {

        int waitTime = calculateWaitingTime(pickUp, destination);

        if (waitTime < 0) {
            return null;
        }

        int travelTime = route.calculateTime(pickUp, destination);

        int boardingTime;

        if (pickUp == 1 || pickUp == 13) {
            boardingTime = route.getDepotTime();
        } else {
            boardingTime = route.getStopTime();
        }

        int totalTime = waitTime + boardingTime + travelTime;

        return LocalTime.now().plusMinutes(totalTime);
    }
}

