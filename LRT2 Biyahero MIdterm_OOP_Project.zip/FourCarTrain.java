/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package j.lrt_midtermproject;

/**
 *
 * @author jacet
 */
public class FourCarTrain extends Train {

    public FourCarTrain(int trainNumber, String direction, Station currentStation) {
        super(trainNumber, direction, currentStation);
    }

    @Override
    public int getCarCount() {
        return 4;
    }

    @Override
    public String getCrowdWarning() {
        if (checkCrowdLevel().equals("High")) {
            return "This train has 4 cars, but high crowding is expected.";
        } else {
            return "This train has 4 cars with standard passenger capacity.";
        }
    }
}
