/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package j.lrt_midtermproject;

/**
 *
 * @author jacet
 */
public class Station {
    private int StationNumber;
    private String StationName;
    
    public Station(int StationNumber, String StationName){
          this.StationName = StationName ;
          this.StationNumber = StationNumber;
    }
    public int getstationNumber(){
        return StationNumber;
    }
    public String getstationName(){
        return StationName;
    }
}
